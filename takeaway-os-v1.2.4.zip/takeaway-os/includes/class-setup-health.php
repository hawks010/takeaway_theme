<?php

defined('ABSPATH') || exit;

final class TTOS_Setup_Health {
    public static function hooks(): void {
        add_action('admin_menu', array(__CLASS__, 'menu'), 24);
        add_action('admin_init', array(__CLASS__, 'handle_posts'));
    }

    public static function menu(): void {
        add_submenu_page('takeaway-os', 'Setup Health', 'Setup Health', 'ttos_manage_settings', 'takeaway-os-setup-health', array(__CLASS__, 'page'));
    }

    public static function handle_posts(): void {
        if (!is_admin() || empty($_POST['ttos_action']) || !current_user_can('ttos_manage_settings')) {
            return;
        }

        $action = sanitize_key(wp_unslash($_POST['ttos_action']));
        $actions = array(
            'setup_health_repair_pages',
            'setup_health_replace_pages',
            'setup_health_assign_core',
            'setup_health_create_starter',
            'setup_health_reset_launchpad',
            'setup_health_run_email_test',
            'setup_health_test_order_mode',
        );

        if (!in_array($action, $actions, true)) {
            return;
        }

        check_admin_referer('ttos_' . $action);

        if ($action === 'setup_health_repair_pages') {
            TTOS_Page_Manager::ensure_all('fresh_if_unsafe');
            TTOS_Page_Manager::sync_front_page_option();
            TTOS_Page_Manager::sync_woocommerce_page_options();
            TTOS_Page_Manager::ensure_theme_menus();
            self::redirect('repair-complete', 'actions');
        }

        if ($action === 'setup_health_replace_pages') {
            if (!current_user_can('manage_options')) {
                wp_die(esc_html__('Only administrators can replace existing page content.', 'takeaway-os'));
            }
            TTOS_Page_Manager::ensure_all('replace');
            TTOS_Page_Manager::sync_front_page_option();
            TTOS_Page_Manager::sync_woocommerce_page_options();
            TTOS_Page_Manager::ensure_theme_menus();
            self::redirect('replace-complete', 'actions');
        }

        if ($action === 'setup_health_assign_core') {
            foreach (array('home', 'menu', 'cart', 'checkout', 'account') as $key) {
                TTOS_Page_Manager::ensure($key, 'fresh_if_unsafe');
            }
            TTOS_Page_Manager::sync_front_page_option();
            TTOS_Page_Manager::sync_woocommerce_page_options();
            TTOS_Page_Manager::ensure_theme_menus();
            self::redirect('assign-complete', 'actions');
        }

        if ($action === 'setup_health_create_starter') {
            TTOS_Page_Manager::ensure_all('fresh_if_unsafe');
            TTOS_Page_Manager::ensure_theme_menus();
            if (class_exists('TTOS_Onboarding')) {
                TTOS_Onboarding::apply_profile();
            }
            if (class_exists('TTOS_Production')) {
                TTOS_Production::apply_starter_menu();
            }
            self::redirect('starter-created', 'actions');
        }

        if ($action === 'setup_health_reset_launchpad') {
            if (class_exists('TTOS_Operations')) {
                TTOS_Operations::update_section('go_live', TTOS_Operations::defaults()['go_live']);
            }
            update_option('ttheme_setup_modal_pending', time(), false);
            self::redirect('launchpad-reset', 'actions');
        }

        if ($action === 'setup_health_run_email_test') {
            $admin_email = sanitize_email((string) get_option('admin_email'));
            if (!$admin_email || !is_email($admin_email)) {
                self::redirect('email-missing', 'actions');
            }
            $subject = 'Takeaway OS test email';
            $message = "This is a Takeaway OS setup health email test.\n\nSite: " . home_url('/') . "\nTime: " . current_time('mysql');
            $sent = wp_mail($admin_email, $subject, $message);
            self::redirect($sent ? 'email-sent' : 'email-failed', 'actions');
        }

        if ($action === 'setup_health_test_order_mode') {
            if (!TTOS_WooCommerce::active()) {
                self::redirect('test-order-guidance', 'actions');
            }
            self::redirect('test-order-guidance', 'actions');
        }
    }

    private static function redirect(string $notice, string $anchor = ''): void {
        $url = add_query_arg(
            array(
                'page' => 'takeaway-os-setup-health',
                'ttos_notice' => $notice,
            ),
            admin_url('admin.php')
        );
        if ($anchor) {
            $url .= '#' . sanitize_key($anchor);
        }
        wp_safe_redirect($url);
        exit;
    }

    public static function page(): void {
        $summary = self::summary();
        self::shell_start('Setup Health', 'Repair the public site, check assignments, and confirm what is still missing before preview or staging handoff.');
        self::summary_panel($summary);
        self::actions_panel();
        self::checks_panel();
        self::shell_end();
    }

    public static function summary(): array {
        $checks = self::checks();
        $pass = 0;
        $warn = 0;
        $fail = 0;
        $pending = array();

        foreach ($checks as $check) {
            if ($check['status'] === 'pass') {
                $pass++;
                continue;
            }
            if ($check['status'] === 'warn') {
                $warn++;
            } else {
                $fail++;
            }
            $pending[] = $check['label'];
        }

        $total = count($checks);
        $progress = $total > 0 ? (int) round(($pass / $total) * 100) : 0;

        return array(
            'checks' => $checks,
            'pass' => $pass,
            'warn' => $warn,
            'fail' => $fail,
            'total' => $total,
            'progress' => $progress,
            'pending' => $pending,
            'core_ready' => self::basic_site_ready($checks),
        );
    }

    public static function checks(): array {
        $checks = array();
        $wc_active = TTOS_WooCommerce::active();
        $gateway_status = self::payment_gateway_status();
        $smtp_status = self::smtp_status();
        $theme_active = self::theme_active();
        $primary_menu_exists = self::nav_menu_exists('Takeaway Primary');
        $footer_menu_exists = self::nav_menu_exists('Takeaway Footer');
        $menu_locations = get_theme_mod('nav_menu_locations', array());
        if (!is_array($menu_locations)) {
            $menu_locations = array();
        }

        $checks[] = self::make_check('ttos_active', 'Takeaway OS active', is_plugin_active(TTOS_BASENAME), 'Takeaway OS is active.', 'Takeaway OS must be active for the launchpad, pages, and order overlay to work.', true);
        $checks[] = self::make_check('woocommerce_active', 'WooCommerce active', $wc_active, $wc_active ? 'WooCommerce is active.' : 'WooCommerce must be active before menu, basket, checkout, and order handling can work.', 'Install or activate WooCommerce from Launchpad.', true);
        $checks[] = self::make_check('woocommerce_version', 'WooCommerce version detected', $wc_active, $wc_active ? 'WooCommerce ' . WC()->version . ' detected.' : 'WooCommerce version cannot be checked until the plugin is active.', 'Install WooCommerce to complete this check.');

        $checks[] = self::page_check('home', 'Homepage exists', 'The homepage record exists.', 'Create or repair the Takeaway homepage.');
        $checks[] = self::assignment_check('home_assigned', 'Homepage is assigned as the WordPress static front page', self::page_is_front_page('home'), 'The Home page is the static front page.', 'Assign Home as the static front page.', true);
        $checks[] = self::page_check('menu', 'Menu page exists', 'The menu page exists.', 'Create or repair the menu page.');
        $checks[] = self::assignment_check('menu_assigned', 'Menu page is assigned as WooCommerce shop page', self::page_matches_option('menu', 'woocommerce_shop_page_id'), 'The Menu page is assigned as the WooCommerce shop page.', 'Assign the Menu page as the WooCommerce shop page.', true);
        $checks[] = self::page_check('cart', 'Basket page exists', 'The Basket page exists.', 'Create or repair the Basket page.');
        $checks[] = self::assignment_check('cart_assigned', 'Basket page is assigned as WooCommerce cart page', self::page_matches_option('cart', 'woocommerce_cart_page_id'), 'The Basket page is assigned as the WooCommerce cart page.', 'Assign the Basket page in WooCommerce.', true);
        $checks[] = self::page_check('checkout', 'Checkout page exists', 'The Checkout page exists.', 'Create or repair the Checkout page.');
        $checks[] = self::assignment_check('checkout_assigned', 'Checkout page is assigned as WooCommerce checkout page', self::page_matches_option('checkout', 'woocommerce_checkout_page_id'), 'The Checkout page is assigned as the WooCommerce checkout page.', 'Assign the Checkout page in WooCommerce.', true);
        $checks[] = self::page_check('account', 'My Account page exists', 'The My Account page exists.', 'Create or repair the My Account page.');
        $checks[] = self::assignment_check('account_assigned', 'My Account page is assigned as WooCommerce account page', self::page_matches_option('account', 'woocommerce_myaccount_page_id'), 'The My Account page is assigned as the WooCommerce account page.', 'Assign the My Account page in WooCommerce.', true);
        $checks[] = self::content_check('tracker', 'Order Tracker page exists and contains correct Takeaway shortcode/marker');
        $checks[] = self::content_check('allergens', 'Allergens page exists and contains correct shortcode/marker');
        $checks[] = self::content_check('delivery', 'Delivery Checker page exists and contains correct shortcode/marker');
        $checks[] = self::content_check('meal_deals', 'Meal Deals page exists and contains correct shortcode/marker');
        $checks[] = self::content_check('rewards', 'Rewards page exists and contains correct shortcode/marker');
        $checks[] = self::make_check('primary_menu_exists', 'Header menu exists', $primary_menu_exists, 'Takeaway Primary exists.', 'Create or repair the header menu.', true);
        $checks[] = self::make_check('primary_menu_assigned', 'Header menu is assigned to the theme primary menu location', !empty($menu_locations['primary']), 'The primary menu location has a menu assigned.', 'Assign a menu to the primary theme location.', true);
        $checks[] = self::make_check('footer_menu_exists', 'Footer menu exists', $footer_menu_exists, 'Takeaway Footer exists.', 'Create or repair the footer menu.', true);
        $checks[] = self::make_check('footer_menu_assigned', 'Footer menu is assigned to the theme footer menu location', !empty($menu_locations['footer']), 'The footer menu location has a menu assigned.', 'Assign a menu to the footer theme location.', true);
        $checks[] = self::make_check('permalinks', 'Permalinks are not plain if possible', get_option('permalink_structure') !== '', 'Pretty permalinks are enabled.', 'Plain permalinks are still enabled. Recommended before public testing.');
        $checks[] = self::make_check('rest_api', 'REST API appears available', function_exists('rest_url') && function_exists('rest_get_server'), 'REST API functions are available.', 'REST API support could not be confirmed from this install.');
        $checks[] = self::make_check('wp_cron', 'WP Cron appears available', !defined('DISABLE_WP_CRON') || !DISABLE_WP_CRON, 'WP Cron is enabled.', 'WP Cron is disabled or unknown. Server cron may still be required.');
        $checks[] = self::make_check('ssl', 'SSL detected on live URL', stripos(home_url('/'), 'https://') === 0, 'The site URL uses HTTPS.', 'The site URL is not using HTTPS yet.');
        $checks[] = self::status_from_tuple('payment_gateway', 'Payment gateway installed/active status', $gateway_status);
        $checks[] = self::status_from_tuple('smtp_plugin', 'SMTP/email plugin status', $smtp_status);
        $checks[] = self::make_check('starter_menu', 'Starter menu content exists', self::starter_content_exists(), 'Published menu products exist.', 'Create starter content or add real menu products.', true);
        $checks[] = self::make_check('theme_active', 'Theme is active', $theme_active, 'The Takeaway theme is active.', 'The site is not currently using the Takeaway theme.', true);

        return $checks;
    }

    public static function launchpad_summary_card(): string {
        $summary = self::summary();
        $pending = array_slice($summary['pending'], 0, 5);

        ob_start();
        echo '<section class="ttos-card ttos-setup-health-summary"><div class="ttos-card-head"><div><p class="ttos-eyebrow">Setup Health</p><h2>' . esc_html((string) $summary['progress']) . '% complete</h2><p class="ttos-muted">Pass: ' . esc_html((string) $summary['pass']) . ' · Warnings: ' . esc_html((string) $summary['warn']) . ' · Failures: ' . esc_html((string) $summary['fail']) . '</p></div>';
        echo '<div class="ttos-installer-actions"><a class="ttos-button" href="' . esc_url(admin_url('admin.php?page=takeaway-os-setup-health')) . '">Open Setup Health</a><button type="button" class="ttos-button ttos-wizard-next" data-next="pages">Finish public site pages</button>';
        if ($summary['core_ready']) {
            echo '<a class="ttos-button ttos-button-dark" href="' . esc_url(home_url('/')) . '" target="_blank" rel="noreferrer noopener">View site</a>';
        }
        echo '</div></div><div class="ttos-big-progress"><span style="width:' . esc_attr((string) $summary['progress']) . '%"></span></div>';
        if ($pending) {
            echo '<p class="ttos-muted">Still missing: ' . esc_html(implode(', ', $pending)) . (count($summary['pending']) > count($pending) ? ' ...' : '') . '</p>';
        } else {
            echo '<p class="ttos-good">Core public pages, menus, and plugin setup checks are all passing.</p>';
        }
        echo '</section>';
        return ob_get_clean();
    }

    private static function summary_panel(array $summary): void {
        echo '<section class="ttos-card"><div class="ttos-card-head"><div><p class="ttos-eyebrow">Setup Readiness</p><h2>' . esc_html((string) $summary['progress']) . '% complete</h2><p class="ttos-muted">This score is based on the setup checks below, not on external browser or payment-provider validation.</p></div><div class="ttos-installer-actions"><a class="ttos-button" href="' . esc_url(admin_url('admin.php?page=takeaway-os-launchpad')) . '">Open Launchpad</a>';
        if ($summary['core_ready']) {
            echo '<a class="ttos-button ttos-button-dark" href="' . esc_url(home_url('/')) . '" target="_blank" rel="noreferrer noopener">View site</a>';
        }
        echo '</div></div><div class="ttos-grid ttos-grid-3"><div class="ttos-mini-card"><strong>' . esc_html((string) $summary['pass']) . '</strong><span>Passing checks</span></div><div class="ttos-mini-card"><strong>' . esc_html((string) $summary['warn']) . '</strong><span>Warnings</span></div><div class="ttos-mini-card"><strong>' . esc_html((string) $summary['fail']) . '</strong><span>Failures</span></div></div><div class="ttos-big-progress"><span style="width:' . esc_attr((string) $summary['progress']) . '%"></span></div>';
        if ($summary['pending']) {
            echo '<div class="ttos-callout"><strong>Still missing:</strong> ' . esc_html(implode(', ', array_slice($summary['pending'], 0, 8))) . (count($summary['pending']) > 8 ? ' ...' : '') . '</div>';
        }
        echo '</section>';
    }

    private static function actions_panel(): void {
        echo '<section id="actions" class="ttos-card"><div class="ttos-card-head"><div><h2>Repair and testing actions</h2><p class="ttos-muted">These actions keep old content safe by default and only replace page content when an administrator explicitly requests it.</p></div></div><div class="ttos-grid ttos-grid-2">';

        self::action_form('setup_health_repair_pages', 'Repair pages and menus', 'Creates missing Takeaway pages, keeps old content safe, assigns homepage/WooCommerce pages, and builds header/footer menus.');
        self::action_form('setup_health_assign_core', 'Assign homepage and WooCommerce pages', 'Re-syncs Home, Menu, Basket, Checkout, and My Account assignments without a destructive reset.');
        self::action_form('setup_health_create_starter', 'Create starter content', 'Applies the Takeaway profile, starter categories, pages, and sample menu products for preview.');
        self::action_form('setup_health_reset_launchpad', 'Reset Launchpad progress', 'Resets the Go Live checklist and re-flags the theme setup prompt for another guided pass.');

        echo '<div class="ttos-mini-card"><h3>View site</h3><p class="ttos-muted">Open the front end in a new tab to review the current public setup.</p><a class="ttos-button" href="' . esc_url(home_url('/')) . '" target="_blank" rel="noreferrer noopener">View site</a></div>';
        echo '<div class="ttos-mini-card"><h3>Open Launchpad</h3><p class="ttos-muted">Jump back into the guided setup flow.</p><a class="ttos-button" href="' . esc_url(admin_url('admin.php?page=takeaway-os-launchpad')) . '">Open Launchpad</a></div>';

        self::action_form('setup_health_run_email_test', 'Run email test', 'Sends a basic test email to the current WordPress admin email if email sending is available.');
        self::action_form('setup_health_test_order_mode', 'Run test order mode setup', 'Shows guidance for enabling a manual/test payment route before placing a staging order.');

        if (current_user_can('manage_options')) {
            self::action_form('setup_health_replace_pages', 'Replace content repair', 'Admin-only: replace existing Takeaway-generated page content instead of creating a fresh safe page.');
        }

        echo '</div></section>';
    }

    private static function checks_panel(): void {
        echo '<section class="ttos-card"><div class="ttos-card-head"><div><h2>Health checks</h2><p class="ttos-muted">Pass/warn/fail cards for the current install state.</p></div></div><div class="ttos-setup-health-grid">';
        foreach (self::checks() as $check) {
            $class = $check['status'] === 'pass' ? 'ttos-good' : ($check['status'] === 'warn' ? 'ttos-warn' : 'ttos-bad');
            echo '<article class="ttos-setup-health-card ' . esc_attr('is-' . $check['status']) . '"><div class="ttos-card-head"><h3>' . esc_html($check['label']) . '</h3><span class="' . esc_attr($class) . '">' . esc_html(strtoupper($check['status'])) . '</span></div><p>' . esc_html($check['message']) . '</p>';
            if (!empty($check['hint'])) {
                echo '<small class="ttos-muted">' . esc_html($check['hint']) . '</small>';
            }
            echo '</article>';
        }
        echo '</div></section>';
    }

    private static function action_form(string $action, string $label, string $description): void {
        echo '<div class="ttos-mini-card"><h3>' . esc_html($label) . '</h3><p class="ttos-muted">' . esc_html($description) . '</p><form method="post">';
        wp_nonce_field('ttos_' . $action);
        echo '<input type="hidden" name="ttos_action" value="' . esc_attr($action) . '"><button class="ttos-button">' . esc_html($label) . '</button></form></div>';
    }

    private static function shell_start(string $title, string $subtitle = ''): void {
        echo '<div class="ttos-wrap"><div class="ttos-shell"><div class="ttos-top"><div><p class="ttos-eyebrow">Takeaway OS</p><h1>' . esc_html($title) . '</h1>';
        if ($subtitle) {
            echo '<p>' . esc_html($subtitle) . '</p>';
        }
        echo '</div><a class="ttos-pill" href="' . esc_url(home_url('/')) . '" target="_blank" rel="noreferrer noopener">View site ↗</a></div>';
        self::nav();
        self::notices();
    }

    private static function shell_end(): void {
        echo '</div></div>';
    }

    private static function nav(): void {
        $items = array(
            'takeaway-os' => 'Dashboard',
            'takeaway-os-launchpad' => 'Launchpad',
            'takeaway-os-setup-health' => 'Setup Health',
            'takeaway-os-menu' => 'Menu',
            'takeaway-os-orders' => 'Orders',
            'takeaway-os-kitchen' => 'Kitchen',
            'takeaway-os-customers' => 'Customers',
            'takeaway-os-reports' => 'Reports',
            'takeaway-os-settings' => 'Settings',
            'takeaway-os-payments' => 'Payments',
            'takeaway-os-delivery' => 'Delivery',
            'takeaway-os-modules' => 'Add-ons',
            'takeaway-os-production' => 'Production',
        );
        $current = isset($_GET['page']) ? sanitize_key($_GET['page']) : 'takeaway-os-setup-health';
        echo '<nav class="ttos-nav">';
        foreach ($items as $slug => $label) {
            if ($slug === 'takeaway-os-modules' && !current_user_can('ttos_modules')) {
                continue;
            }
            echo '<a class="' . esc_attr($current === $slug ? 'active' : '') . '" href="' . esc_url(admin_url('admin.php?page=' . $slug)) . '">' . esc_html($label) . '</a>';
        }
        echo '</nav>';
    }

    private static function notices(): void {
        $notice = sanitize_key($_GET['ttos_notice'] ?? '');
        if ($notice === '') {
            return;
        }

        $messages = array(
            'repair-complete' => 'Setup repair completed in safe mode.',
            'replace-complete' => 'Takeaway page content was replaced on the current mapped pages.',
            'assign-complete' => 'Homepage, WooCommerce pages, and menu locations were reassigned.',
            'starter-created' => 'Starter setup content was created or refreshed.',
            'launchpad-reset' => 'Launchpad progress was reset.',
            'email-sent' => 'A setup health test email was sent to the admin email address.',
            'email-failed' => 'The test email could not be sent. Check your email plugin or mail transport.',
            'email-missing' => 'A valid admin email is required before sending a test email.',
            'test-order-guidance' => 'Next step: open WooCommerce payment settings, enable a safe test/manual gateway, then place a checkout test from the public site.',
        );

        if (isset($messages[$notice])) {
            echo '<div class="ttos-notice">' . esc_html($messages[$notice]) . '</div>';
        }
    }

    private static function make_check(string $id, string $label, bool $pass, string $pass_message, string $fail_message, bool $critical = false): array {
        return array(
            'id' => $id,
            'label' => $label,
            'status' => $pass ? 'pass' : ($critical ? 'fail' : 'warn'),
            'message' => $pass ? $pass_message : $fail_message,
            'hint' => $pass ? '' : ($critical ? 'Use the repair actions above or Launchpad to fix this.' : 'Recommended before staging or live checkout testing.'),
        );
    }

    private static function status_from_tuple(string $id, string $label, array $tuple): array {
        return array(
            'id' => $id,
            'label' => $label,
            'status' => $tuple['status'],
            'message' => $tuple['message'],
            'hint' => $tuple['hint'],
        );
    }

    private static function page_check(string $key, string $label, string $pass_message, string $fail_message): array {
        $status = TTOS_Page_Manager::status($key);
        $ready = !empty($status['id']);
        return self::make_check($key . '_exists', $label, $ready, $pass_message, $fail_message, true);
    }

    private static function assignment_check(string $id, string $label, bool $pass, string $pass_message, string $fail_message, bool $critical = false): array {
        return self::make_check($id, $label, $pass, $pass_message, $fail_message, $critical);
    }

    private static function content_check(string $key, string $label): array {
        $status = TTOS_Page_Manager::status($key);
        $pass = ($status['state'] ?? '') === 'ready';
        return self::make_check($key . '_content', $label, $pass, 'The page exists and contains the expected Takeaway content marker.', 'The page is missing or does not contain the expected Takeaway content yet.', true);
    }

    private static function page_is_front_page(string $key): bool {
        $id = TTOS_Page_Manager::get_page_id($key);
        return $id > 0 && get_option('show_on_front') === 'page' && (int) get_option('page_on_front') === $id;
    }

    private static function page_matches_option(string $key, string $option_name): bool {
        $id = TTOS_Page_Manager::get_page_id($key);
        return $id > 0 && (int) get_option($option_name) === $id;
    }

    private static function nav_menu_exists(string $menu_name): bool {
        return (bool) wp_get_nav_menu_object($menu_name);
    }

    private static function starter_content_exists(): bool {
        if (!post_type_exists('product')) {
            return false;
        }
        $count = wp_count_posts('product');
        return $count && !empty($count->publish);
    }

    private static function payment_gateway_status(): array {
        if (!TTOS_WooCommerce::active() || !class_exists('WC_Payment_Gateways')) {
            return array(
                'status' => 'fail',
                'message' => 'No active payment gateway check is possible until WooCommerce is active.',
                'hint' => 'Activate WooCommerce first, then configure a test/manual or real payment gateway.',
            );
        }

        $enabled = array();
        $installed = array();
        foreach (WC_Payment_Gateways::instance()->payment_gateways() as $gateway) {
            $installed[] = $gateway->get_title();
            if (isset($gateway->enabled) && $gateway->enabled === 'yes') {
                $enabled[] = $gateway->get_title();
            }
        }

        if ($enabled) {
            return array(
                'status' => 'pass',
                'message' => 'Enabled gateway(s): ' . implode(', ', $enabled) . '.',
                'hint' => '',
            );
        }

        return array(
            'status' => 'warn',
            'message' => $installed ? 'Gateways are installed but none are enabled yet.' : 'No payment gateways are available yet.',
            'hint' => 'Enable Stripe, WooPayments, COD, or another safe test gateway before checkout testing.',
        );
    }

    private static function smtp_status(): array {
        $plugins = array(
            'fluent-smtp/fluent-smtp.php' => 'FluentSMTP',
            'wp-mail-smtp/wp_mail_smtp.php' => 'WP Mail SMTP',
            'post-smtp/postman-smtp.php' => 'Post SMTP',
        );
        $active = array();
        $installed = array();
        foreach ($plugins as $file => $label) {
            if (is_plugin_active($file)) {
                $active[] = $label;
                continue;
            }
            if (file_exists(WP_PLUGIN_DIR . '/' . $file)) {
                $installed[] = $label;
            }
        }

        if ($active) {
            return array(
                'status' => 'pass',
                'message' => 'Active email plugin: ' . implode(', ', $active) . '.',
                'hint' => '',
            );
        }
        if ($installed) {
            return array(
                'status' => 'warn',
                'message' => 'Email plugin installed but inactive: ' . implode(', ', $installed) . '.',
                'hint' => 'Activate and configure an SMTP/email delivery plugin before live orders.',
            );
        }

        return array(
            'status' => 'warn',
            'message' => 'No SMTP/email delivery plugin was detected.',
            'hint' => 'Recommended before staging or production email/order testing.',
        );
    }

    private static function theme_active(): bool {
        $theme = wp_get_theme();
        $name = strtolower((string) $theme->get('Name'));
        return strpos($name, 'takeaway') !== false || $theme->get_stylesheet() === 'takeaway-theme' || $theme->get_template() === 'takeaway-theme';
    }

    private static function basic_site_ready(array $checks): bool {
        $required_ids = array(
            'ttos_active',
            'woocommerce_active',
            'home_exists',
            'home_assigned',
            'menu_exists',
            'menu_assigned',
            'cart_exists',
            'cart_assigned',
            'checkout_exists',
            'checkout_assigned',
            'account_exists',
            'account_assigned',
            'primary_menu_exists',
            'primary_menu_assigned',
            'footer_menu_exists',
            'footer_menu_assigned',
            'theme_active',
        );

        foreach ($checks as $check) {
            if (in_array($check['id'], $required_ids, true) && $check['status'] === 'fail') {
                return false;
            }
        }

        return true;
    }
}
