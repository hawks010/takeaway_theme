<?php

defined('ABSPATH') || exit;

final class TTOS_Activator {
    public static function activate(): void {
        self::add_roles();
        self::seed_settings();
        self::create_pages();
        update_option('ttos_version', TTOS_VERSION, false);
        update_option('ttos_do_activation_redirect', '1', false);
        flush_rewrite_rules();
    }

    public static function deactivate(): void {
        $timestamp = wp_next_scheduled('ttos_retry_integrations');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'ttos_retry_integrations');
        }
        flush_rewrite_rules();
    }

    private static function add_roles(): void {
        $manager_caps = array(
            'read'                  => true,
            'ttos_access'           => true,
            'ttos_manage'           => true,
            'ttos_view_orders'      => true,
            'ttos_update_orders'    => true,
            'ttos_manage_menu'      => true,
            'ttos_manage_settings'  => true,
            'ttos_view_reports'     => true,
            'upload_files'          => true,
        );
        add_role('takeaway_owner', __('Takeaway Owner', 'takeaway-os'), $manager_caps);
        add_role('takeaway_manager', __('Takeaway Manager', 'takeaway-os'), $manager_caps);
        add_role('takeaway_kitchen', __('Kitchen Staff', 'takeaway-os'), array(
            'read'               => true,
            'ttos_access'        => true,
            'ttos_view_orders'   => true,
            'ttos_update_orders' => true,
        ));
        add_role('takeaway_driver', __('Delivery Driver', 'takeaway-os'), array(
            'read'               => true,
            'ttos_access'        => true,
            'ttos_view_orders'   => true,
            'ttos_update_orders' => true,
        ));

        $admin = get_role('administrator');
        if ($admin) {
            foreach (array('ttos_access','ttos_manage','ttos_view_orders','ttos_update_orders','ttos_manage_menu','ttos_manage_settings','ttos_view_reports','ttos_modules') as $cap) {
                $admin->add_cap($cap);
            }
        }
    }

    private static function seed_settings(): void {
        if (!get_option('ttos_settings')) {
            update_option('ttos_settings', TTOS_Settings::defaults(), false);
        }
    }

    private static function create_pages(): void {
        // Safe page creation: if an old page already exists but does not contain
        // the required shortcode/marker, create a fresh Takeaway page instead of
        // overwriting old site content.
        TTOS_Page_Manager::ensure_all('fresh_if_unsafe');
        TTOS_Page_Manager::sync_woocommerce_page_options();
    }
}
