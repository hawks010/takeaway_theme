# Takeaway OS v1.2.3

Production hardening pass for Takeaway Theme / Takeaway OS.

## New in v1.2.3

- Dedicated Setup Health admin screen with pass/warn/fail cards.
- Repair actions for pages, menu assignments, starter content, and Launchpad reset.
- Launchpad progress summary with setup percentage and missing-item shortcuts.
- WooCommerce My Account page generation now uses the native WooCommerce account shortcode.

## New in v1.2.2

- Production Tools admin screen.
- Emergency ordering pause switch.
- Menu CSV import/export.
- Starter menu profile with configured kebab, pizza and burger options.
- Safe page repair with fresh/append/replace modes.
- Inventory Lite auto-reset for non-stock sold-out items.
- Low-stock watchlist.
- Campaign email send/export tools for CRM campaigns.
- Client handover report.
- Built-in production readiness meter.
- Fixed hardening page readiness check that could falsely flag generated pages.

## Notes

WooCommerce remains the source of truth for products, cart, checkout, orders, refunds and payment gateways. Takeaway OS provides the restaurant-specific management overlay, public ordering shortcodes and operational cockpit.


## v1.2.3
- Adds Setup Health checks and repair actions for public pages, menu locations, payments, email, and theme state.
- Adds Launchpad setup progress summaries and direct shortcuts into Setup Health.
- Aligns the generated My Account page with WooCommerce page assignments.

## v1.2.2
- Added proper uninstall/data-retention controls.
- Added generated-data markers for safe clean-up of Takeaway pages, menu products and coupons.
- Packaged with Takeaway Theme bundled installer support.
